import { AboutModelDescription } from "./about-model-description";
import { AboutModelHeading } from "./about-model-heading";

export const AboutModel = {
  Description: AboutModelDescription,
  Heading: AboutModelHeading
}