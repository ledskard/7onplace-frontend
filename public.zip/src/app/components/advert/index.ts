import { AdvertExternalLink } from "./advert-link";
import { AdvertRoot } from "./advert-root";

export const Adverts = {
  Root: AdvertRoot,
  ExternalLink: AdvertExternalLink,
};
