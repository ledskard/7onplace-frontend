import { ViewrsContainer } from "./viewrs-container";

export const Viewrs = {
  Container: ViewrsContainer,
};
