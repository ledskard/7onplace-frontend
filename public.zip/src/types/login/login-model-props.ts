export type ModelLoginProps = {
  user: {
    id: string;
    username: string;
  };
  token: string;
};
