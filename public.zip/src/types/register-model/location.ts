export type LocationProps = {
  localizade: string;
  uf: string;
};
