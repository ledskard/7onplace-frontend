import { ModalRoot } from "./modal-root";

export const Modal = {
  Root: ModalRoot,
};
