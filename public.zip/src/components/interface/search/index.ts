import { SearchInput } from "./search-input";

export const Search = {
  Input: SearchInput,
};
