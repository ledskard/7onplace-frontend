import { Star } from "lucide-react";

export const CardModelPremium = () => {
  return (
    <div>
      <Star className="w-7 h-7 text-yellow-500" />
    </div>
  );
};
